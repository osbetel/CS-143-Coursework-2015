package ExpressionTree;

/**
 * @author ADKN
 * @version 15 Mar 2016, 11:03 PM
 */
public class InvalidExpressionException extends Exception {
    public InvalidExpressionException() {
        super();
    }
    public InvalidExpressionException(String message) {
        super(message);
    }
}
